package com.empresalogistica.ICMS.MainActivity

import android.R
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private var mEdiTextEstado: EditText? = null
    private var mEdiTextValor: EditText? = null
    private var mTextViewPorcentagem: TextView? = null
    private var mTextViewTotal: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


    }

    fun calcular(view: View) {
        mEdiTextValor = findViewById(R.id.editTextValor)
        mTextViewPorcentagem = findViewById(R.id.textViewPorcentagem)
        mTextViewTotal = findViewById(R.id.textViewTotal)
        mEdiTextEstado = findViewById(R.id.editTextEstado)
        val estado = mEdiTextEstado!!.text.toString()
        val valorString = mEdiTextValor!!.text.toString()

        val valor = java.lang.Float.parseFloat(valorString)

        var porcentagem = 0f
        //verifica qual estado foi digitado para definir o valor da porcentagem

        when (estado) {
            //Neste caso devemos criar um case para todos estado

            "RO" -> porcentagem = 17.5f

            "SP" -> porcentagem = 18f

            "MG" -> porcentagem = 18f

            "AL" -> porcentagem = 17f

            "RJ" -> porcentagem = 18f
            "AC" -> porcentagem = 17f

            "AM" -> porcentagem = 18f

            "DF" -> porcentagem = 18f

            "ES" -> porcentagem = 17f

            "GO" -> porcentagem = 17f

            "MA" -> porcentagem = 18f

            "MGS" -> porcentagem = 17f

            "PA" -> porcentagem = 18f

            "PB" -> porcentagem = 18f

            "PI" -> porcentagem = 18f

            "RN" -> porcentagem = 18f

            "RS" -> porcentagem = 19f

            "SC" -> porcentagem = 17f

            "SG" -> porcentagem = 18f

            "TO" -> porcentagem = 18f
        }

        //Declara uma nova variavel float com o valor do calculo
        val total = valor + valor * porcentagem / 100

        //Exibi o resultado no TextView para o usuario

        mTextViewPorcentagem!!.text = porcentagem.toString() + "%"
        mTextViewTotal!!.text = String.format("R$ %.2f", total)
    }
}