package com.example.marcos.basquete;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreTA = 0;
    int scoreTB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void pontoParaTA(int scoreTA) {
        TextView scoreView = findViewById(R.id.ptsA);
        scoreView.setText(String.valueOf(scoreTA));
    }
    private void pontoParaTB(int scoreTB) {
        TextView scoreView = findViewById(R.id.ptsB);
        scoreView.setText(String.valueOf(scoreTB));
    }


    public void addtresptsA(View view) {
        scoreTA = scoreTA + 3;
        pontoParaTA(scoreTA);
    }

    public void adddoisptsA(View view) {
        scoreTA = scoreTA + 2;
        pontoParaTA(scoreTA);
    }

    public void addFTA(View view) {
        scoreTA = scoreTA + 1;
        pontoParaTA(scoreTA);
    }

    public void addtresptsB(View view) {
        scoreTB = scoreTB + 3;
        pontoParaTB(scoreTB);
    }

    public void adddoisptsB(View view) {
        scoreTB = scoreTB + 2;
        pontoParaTB(scoreTB);
    }

    public void addFTB(View view) {
        scoreTB = scoreTB + 1;
        pontoParaTB(scoreTB);
    }

    public void reset(View view) {
        scoreTA = 0;
        scoreTB = 0;
        pontoParaTA(scoreTA);
        pontoParaTB(scoreTB);
    }
}